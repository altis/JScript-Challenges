let name = 'Altis'
let postCode = 'SK10'
let myAddress = 'UK'

console.log(`MY name is ${name}`)